import { convertIconsToImages } from '../../.build/helpers.mjs'

await convertIconsToImages('./icons', 'png')
